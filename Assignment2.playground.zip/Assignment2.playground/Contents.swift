//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

// Exercise: Swift Variables

var var1: Int = 15

var var2: Int = 5

var var3: Int = var1 + var2

var var4: Int = var1 * var2

var var5: Int = var1 - var2

var var6: Int = var1 / var2

var var7: String = "Hello"

var var8: String = "World"

var var9: String = var7 + var8

// Exercise: Swift Functions

func add(num1: Double, num2: Double) -> Double {
    return num1 + num2
}

func subtract(num1: Int, num2: Int) -> Int {
    return num1 - num2
}

func multiply(num1:Float, num2:Float) -> Float {
    return num1 * num2
}

add(num1: 0.7, num2: 1.5)

subtract(num1: 20, num2: 12)

multiply(num1: 2.3, num2: 1.5)

// Exercise: Swift Arrays

var array1: [String] = []

var array2: [Double] = [0.2, 0.4, 0.6, 0.8]

var array3 = [1.2, 4, 15, 29, 3,43]

array1.append("Apple")
array1.append("Samsung")
array1.append("Blackberry")

array2.append(2.1)
array2.append(1.4)
array2.append(8.2)

array3.append(1.1)
array3.append(2)
array3.append(3.14)

array1.remove(at: 1)
array2.remove(at: 2)
array3.remove(at: 3)
array3.remove(at: Int(arc4random_uniform(UInt32(array3.count))))
array1.removeAll()

// Exercise: Swift Loops

var oddNumbers: [Int] = []

for index in 1...100 {
    oddNumbers.append(index)
}

var sums: [Int] = []

for index in oddNumbers {
    sums.append(index + 5)
}

var index = 0
repeat{
    print("The sum is: \(sums[index])")
    index += 1
}while index < sums.count

// Exercise: Swift Conditions
// Q1
func fridge(milkAge: Int, eggAge: Int){
    if milkAge <= 21 {
        if eggAge <= 10 {
            print("you can still use your milk and eggs")
        }
        else {
            print("you should throw away the eggs")
        }
    }
    else {
        if milkAge <= 10 {
            print("you can still use your milk and eggs")
        }
        else {
            print("you should throw away both milk and eggs")
        }
    }
}
// test
fridge(milkAge: 23, eggAge: 5)

// Q2
func sameVal(first: Int, second: Int, third: Int){
    if first != second {
        if first != third {
            if second != third {
                print("the values are different")
            }
        }
    }
    print("two values are at least identical")
}
// test
sameVal(first: 10, second: 3, third: 10)

// Exercise: Swift Dictionaries
// Q1
var dicts: [[String: String]] = []
var dict = [String: String]()

dict["firstName"] = "Tianyu"
dict["lastName"] = "Wang"
dicts.append(dict)

dict["firstName"] = "Jay"
dict["lastName"] = "Chou"
dicts.append(dict)

//Q2
var spt: [String] = []
for index in dicts {
    if var firstName = index["firstName"], var lastName = index["lastName"] {
        spt.append(firstName + "^" + lastName)
    }
}
print(spt)

// Exercise: Swift Tuple -  Enum
// Q1
enum coinType: Double {
    case Penny = 0.01
    case Nickel = 0.05
    case Dime = 0.1
    case Quarter = 0.25
    case HalfDollar = 0.5
    case Dollar = 1.0
}

//Q2
var wallet: [(Double, coinType)] = [(1, .Penny), (2, .Nickel), (3, .Dime), (4, .Quarter), (5, .HalfDollar), (6, .Dollar)]

//Q3
var total: Double = 0
for (amount, value) in wallet {
    total += amount * value.rawValue
}
print("Total value: \(total)")
